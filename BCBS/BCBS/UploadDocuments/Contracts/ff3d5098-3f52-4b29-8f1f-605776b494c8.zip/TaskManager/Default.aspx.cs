﻿using System;
using System.Linq;
using Telerik.Web.UI;


namespace TaskManager
{
    public partial class Default : System.Web.UI.Page
    {
        //Page Load
        protected void Page_Load(object sender, EventArgs e)
        {
                  
            GanttCustomField customField = new GanttCustomField();
            customField.Type = GanttCustomFieldType.String;
            customField.PropertyName = "Description";
            customField.ClientPropertyName = "description";
            RadGantt1.CustomTaskFields.Add(customField);

            RadGantt1.Provider = new GanttProvider();

            RadGantt1.DataBind();
        }
    }
}