﻿using System;
using System.Linq;
using System.Data.OracleClient;
using System.Configuration;
using System.Data;
using Telerik.Web.UI.Gantt;
using System.Collections.Generic;
using Telerik.Web.UI;


namespace TaskManager
{
    public partial class GanttProvider : GanttProviderBase
    {
        public override ITaskFactory TaskFactory
        {
            get
            {
                return new CustomGanttTaskFactory();
            }
        }

        #region Tasks

        public override List<ITask> GetTasks()
        {
            var tasks = new List<ITask>();
            using (var db = new TestEntities())
            {
                tasks.AddRange(db.GanttTasks.ToList().Select(task => new CustomTask
                {
                    ID = task.ID,
                    ParentID = task.ParentID,
                    OrderID = task.OrderID,
                    Start = Convert.ToDateTime(task.Start),
                    End = Convert.ToDateTime(task.End),
                    PercentComplete = task.PercentComplete,
                    Summary = task.Summary, //Char to Bool
                    Title = task.Title,
                    Expanded = Convert.ToBoolean(task.Expanded), //Char to Bool
                    Description = task.Description

                }));
            }
            return tasks;
        }


        public override ITask UpdateTask(ITask task)
        {
            using (var db = new TestEntities())
            {          
                GanttTask entityTask = ToEntityTask(task);
                db.GanttTasks.Attach(entityTask);
                db.Entry(entityTask).State = EntityState.Modified;
                db.SaveChanges();
            }

            return task;        
        }

        public override ITask DeleteTask(ITask task)
        {
            using (var db = new TestEntities())
            {
                
                GanttTask entityTask = ToEntityTask(task);
                db.GanttTasks.Attach(entityTask);
                db.GanttTasks.Remove(entityTask);
                db.SaveChanges();
            }

            return task;
        }

        public override ITask InsertTask(ITask task)
        {
            using (var db = new TestEntities())
            {
                task.ID = 0; //Get Largest DB ID +1
                GanttTask entityTask = ToEntityTask(task);
                db.GanttTasks.Add(entityTask);
                db.SaveChanges();

                task.ID = entityTask.ID;
            }

            return task;
        }

        //Task - Next ID
        private int NextID()
        {
            //DataTable------------------------------------------Begin-------------------------------------------------------------------
            OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["ToolboxConnString1"].ConnectionString);
            conn.Open();
            OracleDataAdapter adapter = new OracleDataAdapter(@"SELECT MAX(ID) ID FROM GantTasks", conn);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            conn.Close();
            //DataTable------------------------------------------End-------------------------------------------------------------------

            //Create variable
            var nextID = 0;

            foreach (DataRow row in dt.Rows)
            {
                nextID = row["GANTTTASKS_HMMID"] == DBNull.Value ? 0 : Convert.ToInt32(row["GANTTTASKS_HMMID"]);
            }

            return ++nextID;
        }

        #endregion

        #region Dependencies

        //First Procedure Called
        public override List<IDependency> GetDependencies()
        {
            var dependencies = new List<IDependency>();
            using (var db = new TestEntities())
            {
                dependencies.AddRange(db.GanttDependencies.ToList().Select(dependency => new Dependency()
                {
                    ID = dependency.ID,
                    PredecessorID = dependency.PredecessorID,
                    SuccessorID = dependency.SuccessorID,
                    Type = (DependencyType)dependency.Type
                }));
            }
            return dependencies;
        }

        public override IDependency UpdateDependency(IDependency dependency)
        {
            return dependency;
        }

        public override IDependency DeleteDependency(IDependency dependency)
        {
            using (var db = new TestEntities())
            {
                GanttDependency entityDependency = ToEntityDependency(dependency);
                db.GanttDependencies.Attach(entityDependency);
                db.GanttDependencies.Remove(entityDependency);
                db.SaveChanges();
            }

            return dependency;
        }

        public override IDependency InsertDependency(IDependency dependency)
        {
            using (var db = new TestEntities())
            {
                dependency.ID = 0; //Get Largest DB ID +1
                GanttDependency entityDependency = ToEntityDependency(dependency);
                db.GanttDependencies.Add(entityDependency);
                db.SaveChanges();

                dependency.ID = entityDependency.ID;
            }

            return dependency;
        }

        #endregion

        #region Helpers

        //Update Provider ToEntityTask Method
        //Assign Values from the Edit Form
        private GanttTask ToEntityTask(ITask srcTask)
        {
            return new GanttTask
            {               
                ID = (int)srcTask.ID,
                ParentID = (int?)srcTask.ParentID,
                OrderID = (int)srcTask.OrderID,
                Start = srcTask.Start,
                End = srcTask.End,
                PercentComplete = srcTask.PercentComplete,
                Summary =srcTask.Summary, //Bool to Char
                Title = srcTask.Title,
                Expanded = srcTask.Expanded, //Bool to Char
                Description = ((CustomTask)srcTask).Description
                //DESCRIPTION = "zzzz"
            };
        }

        private GanttDependency ToEntityDependency(IDependency srcDependency)
        {
            return new GanttDependency
            {
                ID = (int)srcDependency.ID,
                PredecessorID = (int)srcDependency.PredecessorID,
                SuccessorID = (int)srcDependency.SuccessorID,
                Type = (int)srcDependency.Type
            };
        }

        //Dependency - Next ID
        private int NextDependencyID()
        {
            //DataTable------------------------------------------Begin-------------------------------------------------------------------
            OracleConnection conn = new OracleConnection(ConfigurationManager.ConnectionStrings["ToolboxConnString1"].ConnectionString);
            conn.Open();
            OracleDataAdapter adapter = new OracleDataAdapter(@"SELECT MAX(ID) IDFROM GANTTDEPENDENCIES", conn);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            conn.Close();
            //DataTable------------------------------------------End-------------------------------------------------------------------

            //Create variable
            var nextID = 0;

            foreach (DataRow row in dt.Rows)
            {
                nextID = row["ID"] == DBNull.Value ? 0 : Convert.ToInt32(row["ID"]);
            }

            return ++nextID;
        }

        #endregion    
    }


    //Create new TaskFactory
    public partial class CustomGanttTaskFactory : ITaskFactory
    {
        Task ITaskFactory.CreateTask()
        {
            return new CustomTask();
        }
    }

    //Create Custom Task class, inheriting from Task
    public partial class CustomTask : Task
    {

        public CustomTask()
            : base()
        {
        }

        //Add custom property
        public string Description
        {
            get { return (string)(ViewState["Description"] ?? ""); }
            set { ViewState["Description"] = value; }
        }

        //Override GetSerializationData
        protected override IDictionary<string, object> GetSerializationData()
        {
            var dict = base.GetSerializationData();
            dict["Description"] = Description;
            return dict;
        }

        //LoadFromDictionary methods
        public override void LoadFromDictionary(System.Collections.IDictionary values)
        {
            base.LoadFromDictionary(values);

            Description = (string)values["Description"];
        }
    }
}